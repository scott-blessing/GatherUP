-- MySQL dump 10.13  Distrib 5.1.73, for unknown-linux-gnu (x86_64)
--
-- Host: engr-cpanel-mysql.engr.illinois.edu    Database: vajpeyi2_gatherup
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Attends`
--

DROP TABLE IF EXISTS `Attends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Attends` (
  `UserEmail` varchar(75) NOT NULL,
  `EventId` int(11) NOT NULL,
  `Carpool` tinyint(1) NOT NULL,
  `Seats` int(11) DEFAULT NULL,
  `Status` int(11) NOT NULL,
  PRIMARY KEY (`UserEmail`,`EventId`),
  KEY `ID` (`EventId`),
  CONSTRAINT `Email` FOREIGN KEY (`UserEmail`) REFERENCES `User` (`Email`) ON DELETE CASCADE,
  CONSTRAINT `ID` FOREIGN KEY (`EventId`) REFERENCES `Event` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Attends`
--

LOCK TABLES `Attends` WRITE;
/*!40000 ALTER TABLE `Attends` DISABLE KEYS */;
INSERT INTO `Attends` (`UserEmail`, `EventId`, `Carpool`, `Seats`, `Status`) VALUES ('dshine.pm@gmail.com',1,0,0,1),('rkelch@illinois.edu',1,0,NULL,2),('vajpeyi2@gmail.com',1,0,0,1);
/*!40000 ALTER TABLE `Attends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Comment`
--

DROP TABLE IF EXISTS `Comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Comment` (
  `ID` int(11) NOT NULL,
  `Text` varchar(100) NOT NULL,
  `Time` datetime NOT NULL,
  `EventId` int(11) NOT NULL,
  `UserEmail` varchar(75) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `EventId` (`EventId`),
  KEY `UserEmail` (`UserEmail`),
  CONSTRAINT `User.Email` FOREIGN KEY (`UserEmail`) REFERENCES `User` (`Email`) ON DELETE CASCADE,
  CONSTRAINT `Event.Id` FOREIGN KEY (`EventId`) REFERENCES `Event` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comment`
--

LOCK TABLES `Comment` WRITE;
/*!40000 ALTER TABLE `Comment` DISABLE KEYS */;
INSERT INTO `Comment` (`ID`, `Text`, `Time`, `EventId`, `UserEmail`) VALUES (1,'hi','2015-04-18 01:16:47',1,'vajpeyi2@gmail.com'),(2,'[Removed By Host]','2015-04-18 01:23:55',1,'vajpeyi2@gmail.com'),(4,'Dhruv here!!!','2015-04-19 15:33:25',1,'vajpeyi2@gmail.com'),(5,'Bitches say shit and they ain\'t ayin nothin','2015-04-19 16:31:47',1,'vajpeyi2@gmail.com'),(6,'Super ultra test comment','2015-04-19 16:57:48',1,'vajpeyi2@gmail.com'),(7,'hello - this is cool','2015-04-19 17:22:23',1,'mazemaster93@hotmail.com'),(8,'[Removed By Host]','2015-04-19 17:23:13',1,'vajpeyi2@gmail.com'),(9,'I literally cannot wait','2015-04-19 20:17:11',4,'mazemaster93@hotmail.com'),(10,'I\'m physically shaking with anticipation','2015-04-19 20:17:39',4,'mazemaster93@hotmail.com'),(11,'Screw you guys','2015-04-19 20:34:50',1,'rkelch@illinois.edu'),(12,'Hey, guys! I can\'t wait to party with you!','2015-04-19 20:38:22',1,'dshine.pm@gmail.com');
/*!40000 ALTER TABLE `Comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Event`
--

DROP TABLE IF EXISTS `Event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Event` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Location` varchar(50) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `HostEmail` varchar(75) NOT NULL,
  `lat` decimal(9,6) NOT NULL,
  `lon` decimal(9,6) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `HostEmail` (`HostEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Event`
--

LOCK TABLES `Event` WRITE;
/*!40000 ALTER TABLE `Event` DISABLE KEYS */;
INSERT INTO `Event` (`ID`, `Name`, `StartTime`, `EndTime`, `Location`, `Description`, `isPublic`, `HostEmail`, `lat`, `lon`) VALUES (1,'Christmas Party','2015-12-25 20:09:40','2015-12-25 23:09:40','1517 Thornwood Dr, Downers Grove IL','Sleigh bells and all that.  Let\'s GatherUP the family and have some fun',1,'mazemaster93@hotmail.com','41.785154','-88.021500'),(3,'Illinites','2015-05-30 11:32:58','2015-05-30 19:32:58','1401 West Green Street, Urbana, IL, United States','GatherUP some freshmen for a good time',1,'mazemaster93@hotmail.com','40.109742','-88.227315'),(4,'Dhruv\'s Death','2015-04-26 20:41:16','2015-04-26 20:45:16','501 E Healey St, Champaign, IL, United States','We kill Dhruv',1,'mazemaster93@hotmail.com','40.111155','-88.231586'),(5,'Jabba the Butt','2015-03-21 19:54:01','2015-03-22 19:54:01','403 East Green Street, Champaign, IL, United State','laom',1,'vajpeyi2@gmail.com','40.110451','-88.235177'),(6,'Shine Party','2015-05-08 18:00:37','2015-05-11 00:00:37','901 West Springfield Avenue, Champaign, IL, United','Party of the year.',1,'dshine.pm@gmail.com','40.112310','-88.258150'),(7,NULL,NULL,NULL,'',NULL,0,'vajpeyi2@gmail.com','0.000000','0.000000');
/*!40000 ALTER TABLE `Event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Supplies`
--

DROP TABLE IF EXISTS `Supplies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Supplies` (
  `Name` varchar(50) NOT NULL,
  `EventId` int(11) NOT NULL,
  PRIMARY KEY (`Name`,`EventId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Supplies`
--

LOCK TABLES `Supplies` WRITE;
/*!40000 ALTER TABLE `Supplies` DISABLE KEYS */;
/*!40000 ALTER TABLE `Supplies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Supply Counts`
--

DROP TABLE IF EXISTS `Supply Counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Supply Counts` (
  `MinAttendeesToNecessetate` int(11) NOT NULL,
  `MaxAttendeesToNecessetate` int(11) NOT NULL,
  ` Quantity` int(11) NOT NULL,
  `Supply.Name` varchar(30) NOT NULL,
  `Event.ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Supply Counts`
--

LOCK TABLES `Supply Counts` WRITE;
/*!40000 ALTER TABLE `Supply Counts` DISABLE KEYS */;
/*!40000 ALTER TABLE `Supply Counts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `Email` varchar(75) NOT NULL,
  `Password` char(128) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `lat` decimal(9,6) NOT NULL,
  `lon` decimal(9,6) NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` (`Email`, `Password`, `Address`, `Username`, `lat`, `lon`) VALUES ('dshine.pm@gmail.com','e17c1ce0ce9769467c48a975252709aaaee7ddd8cd092b04c044a989fdffb2a81eea892952f6207daf69224a87a369a8ae58fd27255eaff8d3160b95e23a6653','901 West Springfield Avenue, Champaign, IL, United States','dShine','40.112310','-88.258150'),('dshine2@illinois.edu','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25','505 E Healey St, Champaign, IL, United States','D33pak','40.111159','-88.231149'),('ho@ho.com','d404559f602eab6fd602ac7680dacbfaadd13630335e951f097af3900e9de176b6db28512f2e000b9d04fba5133e8b1c6e8df59db3a8ab9d60be4b97cc9e81db','','Shin','0.000000','0.000000'),('mayhemaster@hotmail.com','e68f93518bcde257e36a80fc9004b3d2eb8f2a6d200d528d8ffd09516756923c4b83a814db9f883fee4e7a02279024512f51049ded1e37b9b55f12b93db9220f','505 E Healey St, Apt 447','Dhruv','0.000000','0.000000'),('mazemaster93@hotmail.com','e209a32f8d54741f9fa66ea7ac94d708a793a488e51ae27317eb46c271bb2873ea2d32440494c968afa4247d209db2718831415f583e91b845120700be958cd5','1517 Thornwood Drive, Downers Grove, IL, United States','sblessing','41.785154','0.000000'),('rkelch@illinois.edu','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','909 South Locust Street, Champaign, IL, United States','rkelch','40.107036','-88.240658'),('vajpeyi2@gmail.com','e17c1ce0ce9769467c48a975252709aaaee7ddd8cd092b04c044a989fdffb2a81eea892952f6207daf69224a87a369a8ae58fd27255eaff8d3160b95e23a6653','505 E Healey St, Champaign, IL, United States','GroovyDhruvy','40.111159','-88.231149'),('y@y.com','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25','Urba','D2k','40.560000','51.200000'),('yourmother@aol.com','2e96772232487fb3a058d58f2c310023e07e4017c94d56cc5fae4b54b44605f42a75b0b1f358991f8c6cbe9b68b64e5b2a09d0ad23fcac07ee9a9198a745e1d5','q','q','0.000000','0.000000');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vajpeyi2_gatherup'
--

--
-- Dumping routines for database 'vajpeyi2_gatherup'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-19 20:44:04
